#include "helpers.h"
#include "math.h"

// Convert image to grayscale
//The grayscale function takes an image and turn it into a black-and-white version
//Take the average of the red, green, and blue values to determine the shade of grey to make the new pixel
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //If the pixel contains the same value of red, green, blue, continue
            if (image[i][j].rgbtRed == image[i][j].rgbtGreen && image[i][j].rgbtRed == image[i][j].rgbtBlue)
            {
                continue;
            }
            //If the pixel does not contain the same value of red, green, blue, take an average value of red, green, and blue
            else
            {
                //Calculate the average value of red, green, blue
                int avg_rgbt = round(((float)image[i][j].rgbtRed + (float)image[i][j].rgbtGreen + (float)image[i][j].rgbtBlue) / 3.000);
                //Set the colour of the pixel to average value of red, green, blue
                image[i][j].rgbtRed = avg_rgbt;
                image[i][j].rgbtGreen = avg_rgbt;
                image[i][j].rgbtBlue = avg_rgbt;
            }
        }
    }
    return;
}

// Convert image to sepia

//Define limit function: cap the values of red, green, blue at 255
int limit(int rgbt)
{
    if (rgbt > 255)
    {
        rgbt = 255;
    }
    return rgbt;
}

//The sepia function takes an image and turn it into a sepia version
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //Using the provided algorithm, calculate the new red, green, blue values, based on the original values
            //Apply the limit of each value to 255
            int sepiaRed = limit(round(0.393 * image[i][j].rgbtRed + 0.769 * image[i][j].rgbtGreen + 0.189 * image[i][j].rgbtBlue));
            int sepiaGreen = limit(round(0.349 * image[i][j].rgbtRed + 0.686 * image[i][j].rgbtGreen + 0.168 * image[i][j].rgbtBlue));
            int sepiaBlue = limit(round(0.272 * image[i][j].rgbtRed + 0.534 * image[i][j].rgbtGreen + 0.131 * image[i][j].rgbtBlue));
            //Set the colour of the pixel to the new values of red, green, blue
            image[i][j].rgbtRed = sepiaRed;
            image[i][j].rgbtGreen = sepiaGreen;
            image[i][j].rgbtBlue = sepiaBlue;
        }
    }
    return;
}

// Reflect image horizontally
//The reflect function takes an image and reflect it horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        //Split the image in half where the line of reflection is
        for (int j = 0; j < width / 2.000; j++)
        {
            //Assign Array temp to store pixels in the first half of the image
            int temp[3];
            temp[0] = image[i][j].rgbtRed;
            temp[1] = image[i][j].rgbtGreen;
            temp[2] = image[i][j].rgbtBlue;
            //Swap pixels in the first half of the image with the second half of the image
            image[i][j].rgbtRed = image[i][width - j - 1].rgbtRed;
            image[i][j].rgbtGreen = image[i][width - j - 1].rgbtGreen;
            image[i][j].rgbtBlue = image[i][width - j - 1].rgbtBlue;
            //Replace pixels in the second half of the image with the Array temp (pixels in the first half of the image)
            image[i][width - j - 1].rgbtRed = temp[0];
            image[i][width - j - 1].rgbtGreen = temp[1];
            image[i][width - j - 1].rgbtBlue = temp[2];
        }
    }
    return;
}

// Blur image
//The blur function takes an image and turn it into a box-blurred version
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //Calculate the average colour values of each pixel and its neighbouring pixels
            int sumRed = 0;
            int sumGreen = 0;
            int sumBlue = 0;
            float counter = 0.000;
            for (int y = -1; y < 2; y++) //Neighbouring pixel = adjacent pixel (1 pixel to the top & 1 pixel to the bottom)
            {
                if (i + y < 0 || i + y > height - 1)
                {
                    continue; //Continue the calculation for pixels at the top & bottom edges or corner
                }
                for (int x = -1; x < 2; x++) //Neighbouring pixel = adjacent pixel (1 pixel to the left & 1 pixel to the right)
                {
                    if (j + x < 0 || j + x > width - 1)
                    {
                        continue; //Continue the calculation for pixels at the left & right edges or corner
                    }
                    sumRed += image[i + y][j + x].rgbtRed;
                    sumGreen += image[i + y][j + x].rgbtGreen;
                    sumBlue += image[i + y][j + x].rgbtBlue;
                    counter++;
                }
            }
            temp[i][j].rgbtRed = round(sumRed / counter);
            temp[i][j].rgbtGreen = round(sumGreen / counter);
            temp[i][j].rgbtBlue = round(sumBlue / counter);
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            //Set the colour of the pixel to the new values of red, green, blue
            image[i][j].rgbtRed = temp[i][j].rgbtRed;
            image[i][j].rgbtGreen = temp[i][j].rgbtGreen;
            image[i][j].rgbtBlue = temp[i][j].rgbtBlue;
        }
    }
    return;
}
