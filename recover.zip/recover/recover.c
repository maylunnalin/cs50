#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <cs50.h>

//FAT file system with "block size" = 512 bytes
#define buffer_size 512

typedef uint8_t BYTE;

int main(int argc, char *argv[]) //Input: ./recover card.raw
{
    //Check for invalid usage
    if (argc != 2)
    {
        printf("Usage: ./recover filename\n");
        return 1;
    }
    
    //Record filename
    char *filename = argv[1];

    //Open memory card
    FILE *inptr = fopen(filename, "r");
    
    if (inptr == NULL)
    {
        printf("Could not open %s\n", filename);
        return 2;
    }
    
    //Create buffer
    unsigned char buffer[buffer_size]; //Read 512 bytes into a buffer
    
    //Create file arrays
    char file[8]; 
    
    //file counter
    int file_count = 0;
    
    //Create outfile for images
    FILE *outptr = NULL;
    
    //Check if JPEG is found
    bool JPEG_found = false;
    
    //Repeat the following steps until end of card:
    
    //Read files
    //fread(data, size, number, inptr);
    //data: pointer to where to store data you're reading
    //size: size of each element to read (512 bytes chunk)
    //number: number of elements to read
    //inptr: FILE * to read from
    while (fread(buffer, buffer_size, 1, inptr) == 1)
    {
        //If start of new JPEG. (Check first 4 bytes and see if it's a JPEG header or not)
        //First 3 byte: 0xff 0xd8 0xff
        //4th byte: 0xe0, 0xe1, 0xe2, ..., 0xef
        //buffer[0] == 0xff, buffer[1] == 0xd8, buffer[2] == 0xff
        //buffer[3] == 0xe0 || buffer[3] == 0xe1 || buffer[3] == 0xe2 || ... || buffer[3] == 0xef
        //Alternatively, use Bitwise arithmetic: (buffer[3] & 0xf0) == 0xe0 
        //Look at the first 4 bits of this 8-bit byte and set the remaining 4 bits to 0 i.e. 0xe0 = 0xe1 = 0xe2 = ... = 0xef
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            if (JPEG_found == true) //If already found a JPEG
            {
                fclose(outptr); //Close the file you just wrote (so you can open the new file)
            }
            else
            {
                JPEG_found = true;
            }
            sprintf(file, "%03i.jpg", file_count); //Make a new JPEG file. Filenames: ###.jpg, starting at 000.jpg
            outptr = fopen(file, "w"); //Open the new file
            file_count++; //Keep track of the JPEG files you created
        }
        if (JPEG_found == true)
        {
            //Writing files
            //fwrite(data, size, number, inptr);
            //data: pointer to bytes that will be written to file
            //size: size of each element to write
            //number: number of elements to write
            //outptr: FILE * to write to
            fwrite(&buffer, buffer_size, 1, outptr);
        }
    }        
    //Close any remaining files
    fclose(inptr); //Close input
    fclose(outptr); //Close output JPEG file
    return 0; //Success
}
